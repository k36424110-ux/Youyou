# Les Mini-Gardiens - studio gratuit sur GitHub
Voir les étapes dans la conversation. Fichiers : studio.py (le programme), .github/workflows/episode.yml (le bouton "Run").
